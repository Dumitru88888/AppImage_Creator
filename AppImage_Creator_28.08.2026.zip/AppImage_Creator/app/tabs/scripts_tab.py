import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from app.core.mediator import Mediator
from app.utils.paths import get_scripts_dir
from app.utils.tooltip import ToolTip


class ScriptsTab:
    def __init__(self, notebook, mediator: Mediator):
        self.mediator = mediator
        self.frame = ttk.Frame(notebook, padding="10")
        notebook.add(self.frame, text="Scripts")

        self._script_paths = []

        name_frame = ttk.Frame(self.frame)
        name_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(name_frame, text="Script Name:").pack(side=tk.LEFT, padx=(0, 5))
        self.name_entry = ttk.Entry(name_frame, width=30)
        self.name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ToolTip(self.name_entry, "Имя скрипта, например setup.sh.\nЕсли расширение .sh не указано, оно будет добавлено автоматически.")

        editor_frame = ttk.Frame(self.frame)
        editor_frame.pack(fill=tk.BOTH, expand=True, pady=(5, 5))
        ttk.Label(editor_frame, text="Script Content:").pack(anchor=tk.W)
        self.script_text = tk.Text(editor_frame, width=80, height=12, wrap=tk.NONE)
        self.script_text.pack(fill=tk.BOTH, expand=True)
        self.script_text.insert("1.0", "#!/bin/bash\n")
        ToolTip(self.script_text, "Содержимое скрипта на bash.\nСкрипт будет сохранён с правами на выполнение и включён в AppImage.")

        save_frame = ttk.Frame(self.frame)
        save_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Button(save_frame, text="Save Script", command=self.save_script).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(save_frame, text="Add Existing Script", command=self.add_existing_script).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(save_frame, text="Remove Selected", command=self.remove_selected).pack(side=tk.LEFT)

        list_frame = ttk.Frame(self.frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        ttk.Label(list_frame, text="Scripts to include in the AppImage build:").pack(anchor=tk.W)
        self.scripts_listbox = tk.Listbox(list_frame, width=60, height=6, selectmode=tk.EXTENDED)
        self.scripts_listbox.pack(fill=tk.BOTH, expand=True, pady=(5, 0))
        ToolTip(self.scripts_listbox, "Скрипты, которые попадут в AppImage при сборке.\nВыделите элемент, чтобы удалить его кнопкой Remove Selected.")

    def save_script(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showerror("Error", "Please enter a script name.")
            return
        if not name.endswith(".sh"):
            name += ".sh"

        path = get_scripts_dir() / name
        content = self.script_text.get("1.0", tk.END).rstrip("\n") + "\n"
        try:
            path.write_text(content, encoding="utf-8")
            path.chmod(0o755)
        except OSError as e:
            messagebox.showerror("Error", f"Failed to save script:\n{e}")
            return

        self._add_script_path(str(path))
        self.mediator.update_status(f"Script saved to {path}")
        messagebox.showinfo("Info", f"Script saved to {path}")

    def add_existing_script(self):
        paths = filedialog.askopenfilenames(
            title="Select shell scripts",
            filetypes=[("Shell scripts", "*.sh"), ("All files", "*")],
        )
        for p in paths:
            self._add_script_path(p)

    def _add_script_path(self, path: str):
        if path not in self._script_paths:
            self._script_paths.append(path)
            self.scripts_listbox.insert(tk.END, path)

    def remove_selected(self):
        for idx in reversed(self.scripts_listbox.curselection()):
            self._script_paths.pop(idx)
            self.scripts_listbox.delete(idx)

    def get_scripts(self):
        return list(self._script_paths)

    def set_scripts(self, scripts):
        self._script_paths = []
        self.scripts_listbox.delete(0, tk.END)
        for s in scripts:
            self._add_script_path(os.path.abspath(str(s)))
