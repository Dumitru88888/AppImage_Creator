import subprocess
from pathlib import Path

BUILDS_DIR_NAME = "Сборки AppImage"
SCRIPTS_DIR_NAME = "Скрипты"


def get_desktop_dir() -> Path:
    try:
        result = subprocess.run(
            ["xdg-user-dir", "DESKTOP"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            path = Path(result.stdout.strip())
            if path.is_dir():
                return path
    except (OSError, subprocess.SubprocessError):
        pass
    return Path.home() / "Desktop"


def get_builds_dir() -> Path:
    builds_dir = get_desktop_dir() / BUILDS_DIR_NAME
    builds_dir.mkdir(parents=True, exist_ok=True)
    return builds_dir


def get_scripts_dir() -> Path:
    scripts_dir = get_desktop_dir() / SCRIPTS_DIR_NAME
    scripts_dir.mkdir(parents=True, exist_ok=True)
    return scripts_dir
