from app.utils.constants import (
    APP_NAME,
    APP_VERSION,
    DEFAULT_APP_VERSION,
    LINUXDEPLOY_URLS,
    VALID_CATEGORIES,
    REQUIRED_DESKTOP_FIELDS,
    DEFAULT_COMMENT,
    ICON_SIZE,
    ICON_DIR,
    BIN_DIR,
    APPLICATIONS_DIR,
    LIB_DIR,
)
from app.utils.types import BuildConfig, ValidationResult
