#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AppImage Builder — единый файл.

Объединяет все модули проекта app_image_creator в один скрипт:
  * русский интерфейс (с переключением RU/EN),
  * обновлённый дизайн (тема, цвета, отступы, акцентная кнопка),
  * сборка AppImage, валидатор .desktop, менеджер зависимостей.

Запуск:  python app_image_creator_single.py
"""

import json
import os
import platform
import shutil
import subprocess
import threading
import tkinter as tk
from dataclasses import dataclass, field
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk
from typing import Callable, List, Optional

# ============================================================================
# Константы
# ============================================================================

APP_NAME = "AppImage Builder"
APP_VERSION = "1.0.0"
DEFAULT_APP_VERSION = "1.0"

LINUXDEPLOY_URLS = {
    'arm64': 'https://github.com/linuxdeploy/linuxdeploy/releases/download/1-alpha-20250213-2/linuxdeploy-aarch64.AppImage',
    'amd64': 'https://github.com/linuxdeploy/linuxdeploy/releases/download/1-alpha-20250213-2/linuxdeploy-x86_64.AppImage',
}

VALID_CATEGORIES = [
    'AudioVideo', 'Audio', 'Video', 'Graphics', 'Office',
    'Development', 'Education', 'Game', 'Network', 'Settings',
    'System', 'Utility',
]

REQUIRED_DESKTOP_FIELDS = ['Name', 'Exec', 'Type', 'Categories']

DEFAULT_COMMENT_RU = "Приложение, созданное в AppImage Builder"
DEFAULT_COMMENT_EN = "App created with AppImage Builder"

ICON_SIZE = '256x256'
ICON_DIR = f'usr/share/icons/hicolor/{ICON_SIZE}/apps'
BIN_DIR = 'usr/bin'
APPLICATIONS_DIR = 'usr/share/applications'
LIB_DIR = 'usr/lib'

# --- Палитра нового дизайна ---
COLOR_BG = '#f4f6fa'
COLOR_CARD = '#ffffff'
COLOR_ACCENT = '#2563eb'
COLOR_ACCENT_DARK = '#1e40af'
COLOR_TEXT = '#1f2937'
COLOR_MUTED = '#6b7280'
COLOR_OK = '#16a34a'
COLOR_WARN = '#d97706'
COLOR_ERR = '#dc2626'
COLOR_LOG_BG = '#0f172a'
COLOR_LOG_FG = '#e2e8f0'

# ============================================================================
# Локализация (RU / EN)
# ============================================================================

STRINGS = {
    'ru': {
        'title': f"{APP_NAME} — конструктор AppImage",
        'header': "Конструктор AppImage",
        'subtitle': "Сборка переносимых Linux-приложений",
        'status_ready': "Готово",
        'language': "Язык",
        # Вкладки
        'tab_build': "Сборка",
        'tab_validator': "Валидатор .desktop",
        'tab_deps': "Зависимости",
        # Поля сборки
        'executable': "Исполняемый файл:",
        'icon': "Значок (.png):",
        'app_name': "Название:",
        'version': "Версия:",
        'category': "Категория:",
        'comment': "Описание:",
        'browse': "Обзор…",
        'select_exe_title': "Выберите исполняемый файл",
        'select_icon_title': "Выберите значок",
        'png_files': "Файлы PNG",
        'all_files': "Все файлы",
        # Кнопки
        'save_config': "Сохранить конфигурацию",
        'load_config': "Загрузить конфигурацию",
        'generate': "Собрать AppImage",
        'cancel': "Отменить",
        'clear': "Очистить",
        # linuxdeploy
        'linuxdeploy_ok': "linuxdeploy: установлен",
        'linuxdeploy_missing': "linuxdeploy: не найден",
        'install_linuxdeploy': "Установить linuxdeploy",
        'ld_already': "linuxdeploy уже установлен.",
        'ld_install_prompt_t': "Установка linuxdeploy",
        'ld_install_prompt_m': "linuxdeploy не установлен. Скачать и установить его сейчас?",
        'ld_install_fail': "Не удалось установить linuxdeploy. Подробности в журнале.",
        # Журнал
        'build_log': "Журнал сборки:",
        # Сообщения
        'err_fill_fields': "Заполните все обязательные поля.",
        'err_exe_not_found': "Исполняемый файл не найден: {}",
        'err_icon_not_found': "Файл значка не найден: {}",
        'err_title': "Ошибка",
        'err_save_cfg': "Не удалось сохранить конфигурацию:\n{}",
        'err_load_json': "Некорректный JSON-файл:\n{}",
        'err_read_file': "Не удалось прочитать файл:\n{}",
        'err_build_failed': "Сборка не удалась:\n{}",
        'unexpected_error': "Непредвиденная ошибка: {}",
        'cfg_saved': "Конфигурация сохранена: {}",
        'cfg_loaded': "Конфигурация загружена: {}",
        'save_cfg_title': "Сохранить конфигурацию",
        'load_cfg_title': "Загрузить конфигурацию",
        'json_files': "Файлы JSON",
        'success_title': "Готово",
        'success_build': "AppImage успешно собран!",
        'info_title': "Информация",
        'build_cancelled': "Сборка отменена.",
        'cancelling': "Отмена сборки…",
        # Ход сборки
        'log_creating_appdir': "Создание AppDir: {}",
        'log_desktop_created': "Файл .desktop создан: {}",
        'log_apprun_created': "AppRun создан: {}",
        'log_dep_added': "Добавлена зависимость: {}",
        'log_ld_missing': "linuxdeploy не найден. Установите его для создания AppImage.",
        'log_running_ld': "Запуск linuxdeploy для поиска зависимостей…",
        'log_executing': "Выполняется: {}",
        'log_build_error': "Ошибка при создании AppImage.",
        'log_categories_issue': "Похоже, проблема в категориях файла .desktop.",
        'log_check_validator': "Проверьте вкладку «Валидатор .desktop».",
        'log_build_ok': "AppImage успешно собран!",
        # Валидатор
        'desktop_content': "Содержимое файла .desktop:",
        'validate_btn': "Проверить файл",
        'validation_failed': "Валидация НЕ пройдена: {}",
        'validation_warn': "Валидация пройдена с предупреждениями: {}",
        'validation_passed': "Валидация пройдена",
        'missing_field': "Отсутствует обязательное поле: {}",
        'bad_category': "Категория «{}» не является стандартной. Используйте одну из стандартных категорий.",
        'no_validator': "Вкладка валидатора не зарегистрирована",
        'no_sample_comment': "Пример приложения",
        # Зависимости
        'add_dependency': "Добавить зависимость:",
        'add': "Добавить",
        'sort': "Сортировать",
        'dep_list': "Список зависимостей:",
        'select_deps_title': "Выберите файлы зависимостей",
        'remove_selected': "Удалить выбранные",
        'clear_all': "Очистить всё",
    },
    'en': {
        'title': f"{APP_NAME}",
        'header': "AppImage Builder",
        'subtitle': "Build portable Linux applications",
        'status_ready': "Ready",
        'language': "Language",
        'tab_build': "Build",
        'tab_validator': "Desktop Validator",
        'tab_deps': "Dependencies",
        'executable': "Executable:",
        'icon': "Icon (.png):",
        'app_name': "App Name:",
        'version': "Version:",
        'category': "Category:",
        'comment': "Comment:",
        'browse': "Browse…",
        'select_exe_title': "Select executable",
        'select_icon_title': "Select icon",
        'png_files': "PNG files",
        'all_files': "All files",
        'save_config': "Save Config",
        'load_config': "Load Config",
        'generate': "Generate AppImage",
        'cancel': "Cancel",
        'clear': "Clear",
        'linuxdeploy_ok': "linuxdeploy: available",
        'linuxdeploy_missing': "linuxdeploy: not found",
        'install_linuxdeploy': "Install linuxdeploy",
        'ld_already': "linuxdeploy is already installed.",
        'ld_install_prompt_t': "Install linuxdeploy",
        'ld_install_prompt_m': "linuxdeploy is not installed. Download and install it now?",
        'ld_install_fail': "linuxdeploy installation failed. Check the log for details.",
        'build_log': "Build Log:",
        'err_fill_fields': "Please complete all required fields.",
        'err_exe_not_found': "Executable file not found: {}",
        'err_icon_not_found': "Icon file not found: {}",
        'err_title': "Error",
        'err_save_cfg': "Failed to save configuration:\n{}",
        'err_load_json': "Invalid JSON file:\n{}",
        'err_read_file': "Failed to read file:\n{}",
        'err_build_failed': "Build failed:\n{}",
        'unexpected_error': "Unexpected error: {}",
        'cfg_saved': "Configuration saved to {}",
        'cfg_loaded': "Configuration loaded from {}",
        'save_cfg_title': "Save Configuration",
        'load_cfg_title': "Load Configuration",
        'json_files': "JSON files",
        'success_title': "Success",
        'success_build': "AppImage generated successfully!",
        'info_title': "Info",
        'build_cancelled': "Build cancelled.",
        'cancelling': "Cancelling build...",
        'log_creating_appdir': "Creating AppDir in {}",
        'log_desktop_created': "Desktop file created at {}",
        'log_apprun_created': "AppRun created at {}",
        'log_dep_added': "Added dependency: {}",
        'log_ld_missing': "linuxdeploy not found. Please install it to create AppImages.",
        'log_running_ld': "Running linuxdeploy to detect dependencies...",
        'log_executing': "Executing: {}",
        'log_build_error': "Error during AppImage creation.",
        'log_categories_issue': "It seems there's an issue with the desktop file categories.",
        'log_check_validator': "Please check the Desktop File Validator tab for details.",
        'log_build_ok': "AppImage generated successfully!",
        'desktop_content': "Desktop File Content:",
        'validate_btn': "Validate File",
        'validation_failed': "Validation FAILED: {}",
        'validation_warn': "Validation PASSED with warnings: {}",
        'validation_passed': "Validation PASSED",
        'missing_field': "Missing required field: {}",
        'bad_category': "Category '{}' is not a standard category. Consider using one of the standard categories.",
        'no_validator': "No validator tab registered",
        'no_sample_comment': "A sample application",
        'add_dependency': "Add Dependency:",
        'add': "Add",
        'sort': "Sort",
        'dep_list': "Dependency List:",
        'select_deps_title': "Select dependency files",
        'remove_selected': "Remove Selected",
        'clear_all': "Clear All",
    },
}

_current_lang = 'ru'


def tr(key: str, *args) -> str:
    s = STRINGS[_current_lang].get(key) or STRINGS['en'].get(key, key)
    return s.format(*args) if args else s


def set_language(lang: str) -> None:
    global _current_lang
    _current_lang = lang


def get_language() -> str:
    return _current_lang


# ============================================================================
# Типы данных
# ============================================================================

@dataclass
class BuildConfig:
    name: str
    version: str
    category: str
    comment: str
    executable_path: Path
    icon_path: Optional[Path] = None
    extra_deps: List[Path] = field(default_factory=list)


@dataclass
class ValidationResult:
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        if self.errors:
            return tr('validation_failed', "; ".join(self.errors))
        if self.warnings:
            return tr('validation_warn', "; ".join(self.warnings))
        return tr('validation_passed')

    @property
    def color(self) -> str:
        if self.errors:
            return COLOR_ERR
        if self.warnings:
            return COLOR_WARN
        return COLOR_OK


# ============================================================================
# Сервисы
# ============================================================================

class DesktopFileHandler:
    def generate(self, config: BuildConfig) -> str:
        return (
            f"[Desktop Entry]\n"
            f"Name={config.name}\n"
            f"Exec={config.name}\n"
            f"Icon={config.name}\n"
            f"Type=Application\n"
            f"Categories={config.category};\n"
            f"Comment={config.comment}\n"
            "Version=1.0\n"
        )

    def validate(self, content: str) -> ValidationResult:
        lines = content.split('\n')
        errors: List[str] = []
        warnings: List[str] = []
        present_fields: List[str] = []

        for line in lines:
            line = line.strip()
            if '=' not in line:
                continue
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()

            if key in REQUIRED_DESKTOP_FIELDS:
                present_fields.append(key)

            if key == 'Categories':
                category_value = value.rstrip(';')
                if category_value not in VALID_CATEGORIES:
                    warnings.append(tr('bad_category', category_value))

        for f in REQUIRED_DESKTOP_FIELDS:
            if f not in present_fields:
                errors.append(tr('missing_field', f))

        return ValidationResult(is_valid=len(errors) == 0, errors=errors, warnings=warnings)

    def get_sample(self) -> str:
        return (
            "[Desktop Entry]\n"
            "Name=My Application\n"
            "Exec=myapp\n"
            "Icon=myapp\n"
            "Type=Application\n"
            "Categories=Utility;\n"
            f"Comment={tr('no_sample_comment')}\n"
        )


class AppDirBuilder:
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.appdir_path: Optional[Path] = None

    def create(self, config: BuildConfig) -> Path:
        self.appdir_path = self.base_dir / f"{config.name}.AppDir"
        if self.appdir_path.exists():
            shutil.rmtree(self.appdir_path)
        for sub in (BIN_DIR, ICON_DIR, APPLICATIONS_DIR, LIB_DIR):
            (self.appdir_path / sub).mkdir(parents=True, exist_ok=True)
        return self.appdir_path

    def cleanup(self) -> None:
        if self.appdir_path and self.appdir_path.exists():
            shutil.rmtree(self.appdir_path)
            self.appdir_path = None

    def add_executable(self, src: Path) -> Path:
        dest = self.appdir_path / BIN_DIR / src.name
        shutil.copy2(src, dest)
        return dest

    def add_icon(self, src: Path, name: str) -> Path:
        dest = self.appdir_path / ICON_DIR / f"{name}.png"
        shutil.copy2(src, dest)
        return dest

    def create_desktop_file(self, config: BuildConfig, content: str) -> Path:
        desktop_path = self.appdir_path / APPLICATIONS_DIR / f"{config.name}.desktop"
        desktop_path.write_text(content, encoding='utf-8')
        return desktop_path

    def create_apprun_script(self, executable_name: str) -> Path:
        apprun_content = (
            "#!/bin/bash\n"
            'HERE="$(dirname "$(readlink -f "${0}")")"\n'
            'export LD_LIBRARY_PATH="$HERE/usr/lib:$LD_LIBRARY_PATH"\n'
            f'exec "$HERE/usr/bin/{executable_name}" "$@"\n'
        )
        apprun_path = self.appdir_path / "AppRun"
        apprun_path.write_text(apprun_content, encoding='utf-8')
        apprun_path.chmod(0o755)
        return apprun_path


class LinuxDeployManager:
    def is_available(self) -> bool:
        return shutil.which("linuxdeploy") is not None

    def get_version(self) -> Optional[str]:
        if not self.is_available():
            return None
        try:
            result = subprocess.run(
                ["linuxdeploy", "--version"], capture_output=True, text=True, timeout=5,
            )
            return result.stdout.strip() or result.stderr.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None

    def get_url(self, arch: str = None) -> Optional[str]:
        if arch is None:
            arch = platform.machine().lower()
        arch_map = {'aarch64': 'arm64', 'arm64': 'arm64', 'x86_64': 'amd64', 'amd64': 'amd64'}
        return LINUXDEPLOY_URLS.get(arch_map.get(arch))

    def install(self, log_callback: Callable[[str], None] = None) -> bool:
        url = self.get_url()
        if not url:
            if log_callback:
                log_callback("Unsupported CPU architecture for automatic install.")
            return False
        if not shutil.which("pkexec"):
            if log_callback:
                log_callback("pkexec not found. Install policykit or run install_appimage_tools.sh manually.")
            return False
        if log_callback:
            log_callback("Installing linuxdeploy...")

        install_cmd = [
            "pkexec", "bash", "-c",
            "set -e; TMP_DIR=$(mktemp -d); cd \"$TMP_DIR\"; "
            f"wget -c \"{url}\" -O linuxdeploy.AppImage; "
            "chmod +x linuxdeploy.AppImage; "
            "mv linuxdeploy.AppImage /usr/local/bin/linuxdeploy; "
            "cd ~; rm -rf \"$TMP_DIR\""
        ]
        try:
            process = subprocess.Popen(
                install_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            )
            output = ""
            for line in iter(process.stdout.readline, ''):
                if line:
                    output += line
                    if log_callback:
                        log_callback(line.strip())
            process.stdout.close()
            process.wait()
            if process.returncode != 0:
                if log_callback:
                    log_callback("linuxdeploy installation failed.")
                return False
            if log_callback:
                log_callback("linuxdeploy installed successfully.")
            return True
        except Exception as e:
            if log_callback:
                log_callback(f"Installation error: {e}")
            return False

    def ensure_available(self, log_callback: Callable[[str], None] = None) -> bool:
        if self.is_available():
            return True
        return self.install(log_callback)


# ============================================================================
# Медиатор
# ============================================================================

class Mediator:
    def __init__(self):
        self._build_tab: Optional['BuildTab'] = None
        self._validator_tab: Optional['ValidatorTab'] = None
        self._dependencies_tab: Optional['DependenciesTab'] = None
        self._status_callback = None

    def set_status_callback(self, callback):
        self._status_callback = callback

    def register_build_tab(self, tab: 'BuildTab') -> None:
        self._build_tab = tab

    def register_validator_tab(self, tab: 'ValidatorTab') -> None:
        self._validator_tab = tab

    def register_dependencies_tab(self, tab: 'DependenciesTab') -> None:
        self._dependencies_tab = tab

    def update_status(self, message: str) -> None:
        if self._status_callback:
            self._status_callback(message)

    def set_desktop_content(self, content: str) -> None:
        if self._validator_tab:
            self._validator_tab.set_content(content)

    def get_desktop_content(self) -> str:
        if self._validator_tab:
            return self._validator_tab.get_content()
        return ""

    def validate_desktop_file(self) -> ValidationResult:
        if self._validator_tab:
            return self._validator_tab.validate()
        return ValidationResult(is_valid=False, errors=[tr('no_validator')])

    def get_dependencies(self) -> List[str]:
        if self._dependencies_tab:
            return self._dependencies_tab.get_dependencies()
        return []

    def set_dependencies(self, deps: List[str]) -> None:
        if self._dependencies_tab:
            self._dependencies_tab.set_dependencies(deps)

    def rebuild_ui_texts(self) -> None:
        """Перестроить тексты всех вкладок после смены языка."""
        if self._build_tab:
            self._build_tab.apply_language()
        if self._validator_tab:
            self._validator_tab.apply_language()
        if self._dependencies_tab:
            self._dependencies_tab.apply_language()


# ============================================================================
# Вкладка сборки
# ============================================================================

class BuildTab:
    def __init__(self, notebook, mediator: Mediator):
        self.mediator = mediator
        self.linuxdeploy = LinuxDeployManager()
        self.desktop_handler = DesktopFileHandler()
        self.frame = ttk.Frame(notebook, padding=(16, 12))
        notebook.add(self.frame, text=tr('tab_build'))

        self._build_process = None
        self._build_thread = None
        self._builder = None
        self._appdir_path = None

        self._build_ui()
        self.exe_entry.focus()
        self._update_linuxdeploy_status()

    def _build_ui(self):
        # --- Карточка «Файлы» ---
        files = ttk.LabelFrame(self.frame, text="  ", padding=(12, 8))
        files.pack(fill=tk.X, pady=(0, 8))

        self.exe_label = ttk.Label(files, text=tr('executable'))
        self.exe_label.grid(row=0, column=0, sticky=tk.W, pady=3)
        self.exe_entry = ttk.Entry(files)
        self.exe_entry.grid(row=0, column=1, sticky=tk.EW, pady=3, padx=(8, 6))
        ttk.Button(files, text=tr('browse'), command=self.select_executable).grid(row=0, column=2)

        self.icon_label = ttk.Label(files, text=tr('icon'))
        self.icon_label.grid(row=1, column=0, sticky=tk.W, pady=3)
        self.icon_entry = ttk.Entry(files)
        self.icon_entry.grid(row=1, column=1, sticky=tk.EW, pady=3, padx=(8, 6))
        ttk.Button(files, text=tr('browse'), command=self.select_icon).grid(row=1, column=2)

        files.columnconfigure(1, weight=1)

        # --- Карточка «Метаданные» ---
        meta = ttk.LabelFrame(self.frame, text="  ", padding=(12, 8))
        meta.pack(fill=tk.X, pady=(0, 8))

        self.name_label = ttk.Label(meta, text=tr('app_name'))
        self.name_label.grid(row=0, column=0, sticky=tk.W, pady=3)
        self.name_entry = ttk.Entry(meta, width=28)
        self.name_entry.grid(row=0, column=1, sticky=tk.W, pady=3, padx=(8, 20))

        self.version_label = ttk.Label(meta, text=tr('version'))
        self.version_label.grid(row=0, column=2, sticky=tk.W, pady=3)
        self.version_entry = ttk.Entry(meta, width=14)
        self.version_entry.grid(row=0, column=3, sticky=tk.W, pady=3, padx=(8, 0))

        self.category_label = ttk.Label(meta, text=tr('category'))
        self.category_label.grid(row=1, column=0, sticky=tk.W, pady=3)
        self.category_var = tk.StringVar()
        self.category_combo = ttk.Combobox(
            meta, width=26, textvariable=self.category_var, values=VALID_CATEGORIES,
        )
        self.category_combo.grid(row=1, column=1, sticky=tk.W, pady=3, padx=(8, 20))
        self.category_combo.set("Game")

        self.comment_label = ttk.Label(meta, text=tr('comment'))
        self.comment_label.grid(row=1, column=2, sticky=tk.W, pady=3)
        self.comment_entry = ttk.Entry(meta, width=26)
        self.comment_entry.grid(row=1, column=3, sticky=tk.W, pady=3, padx=(8, 0))
        self.comment_entry.insert(0, DEFAULT_COMMENT_RU if get_language() == 'ru' else DEFAULT_COMMENT_EN)

        # --- Кнопки действий ---
        actions = ttk.Frame(self.frame)
        actions.pack(fill=tk.X, pady=(0, 8))
        self.save_cfg_button = ttk.Button(actions, text=tr('save_config'), command=self._save_config)
        self.save_cfg_button.pack(side=tk.LEFT, padx=(0, 6))
        self.load_cfg_button = ttk.Button(actions, text=tr('load_config'), command=self._load_config)
        self.load_cfg_button.pack(side=tk.LEFT, padx=(0, 6))
        self.generate_button = ttk.Button(
            actions, text=tr('generate'), style='Accent.TButton', command=self.build_appimage,
        )
        self.generate_button.pack(side=tk.LEFT, padx=(0, 6))
        self.cancel_button = ttk.Button(
            actions, text=tr('cancel'), command=self._cancel_build, state=tk.DISABLED,
        )
        self.cancel_button.pack(side=tk.LEFT)

        # --- Статус linuxdeploy ---
        ld = ttk.Frame(self.frame)
        ld.pack(fill=tk.X, pady=(0, 8))
        self.linuxdeploy_status_label = ttk.Label(ld, text="")
        self.linuxdeploy_status_label.pack(side=tk.LEFT)
        self.install_linuxdeploy_button = ttk.Button(
            ld, text=tr('install_linuxdeploy'), command=self._prompt_install_linuxdeploy,
        )
        self.install_linuxdeploy_button.pack(side=tk.RIGHT)

        # --- Журнал ---
        log_frame = ttk.LabelFrame(self.frame, text="  ", padding=(12, 8))
        log_frame.pack(fill=tk.BOTH, expand=True)
        header = ttk.Frame(log_frame)
        header.pack(fill=tk.X, pady=(0, 4))
        self.log_label = ttk.Label(header, text=tr('build_log'))
        self.log_label.pack(side=tk.LEFT)
        ttk.Button(header, text=tr('clear'), command=self._clear_log).pack(side=tk.RIGHT)

        self.log_text = scrolledtext.ScrolledText(
            log_frame, height=12, bg=COLOR_LOG_BG, fg=COLOR_LOG_FG,
            relief=tk.FLAT, insertbackground=COLOR_LOG_FG, font=('Consolas', 10),
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)

    # --- Переключение языка ---
    def apply_language(self):
        self.frame.master.tab(self.frame, text=tr('tab_build'))
        self.exe_label.config(text=tr('executable'))
        self.icon_label.config(text=tr('icon'))
        self.name_label.config(text=tr('app_name'))
        self.version_label.config(text=tr('version'))
        self.category_label.config(text=tr('category'))
        self.comment_label.config(text=tr('comment'))
        self.save_cfg_button.config(text=tr('save_config'))
        self.load_cfg_button.config(text=tr('load_config'))
        self.log_label.config(text=tr('build_log'))
        self.install_linuxdeploy_button.config(text=tr('install_linuxdeploy'))
        self.generate_button.config(text=tr('generate'))
        self.cancel_button.config(text=tr('cancel'))
        self._update_linuxdeploy_status()

    # --- Выбор файлов ---
    def select_executable(self):
        path = filedialog.askopenfilename(title=tr('select_exe_title'), filetypes=[(tr('all_files'), "*")])
        if path:
            self.exe_entry.delete(0, tk.END)
            self.exe_entry.insert(0, path)
            if not self.name_entry.get():
                name = os.path.splitext(os.path.basename(path))[0]
                self.name_entry.insert(0, name)

    def select_icon(self):
        path = filedialog.askopenfilename(title=tr('select_icon_title'), filetypes=[(tr('png_files'), "*.png")])
        if path:
            self.icon_entry.delete(0, tk.END)
            self.icon_entry.insert(0, path)

    # --- Журнал ---
    def log_message(self, message):
        self.frame.after(0, self._append_log, message)

    def _append_log(self, message):
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.mediator.update_status(message)

    def _clear_log(self):
        self.log_text.delete("1.0", tk.END)

    # --- linuxdeploy ---
    def _update_linuxdeploy_status(self):
        if self.linuxdeploy.is_available():
            self.linuxdeploy_status_label.config(text=tr('linuxdeploy_ok'), foreground=COLOR_OK)
            self.install_linuxdeploy_button.config(state=tk.DISABLED)
        else:
            self.linuxdeploy_status_label.config(text=tr('linuxdeploy_missing'), foreground=COLOR_ERR)
            self.install_linuxdeploy_button.config(state=tk.NORMAL)

    def _prompt_install_linuxdeploy(self):
        if self.linuxdeploy.is_available():
            messagebox.showinfo(tr('info_title'), tr('ld_already'))
            self._update_linuxdeploy_status()
            return
        if not messagebox.askyesno(tr('ld_install_prompt_t'), tr('ld_install_prompt_m')):
            return
        success = self.linuxdeploy.install(log_callback=self._append_log)
        if not success:
            messagebox.showerror(tr('err_title'), tr('ld_install_fail'))
        self._update_linuxdeploy_status()

    # --- Конфигурация ---
    def _save_config(self):
        path = filedialog.asksaveasfilename(
            title=tr('save_cfg_title'), defaultextension=".json",
            filetypes=[(tr('json_files'), "*.json")],
        )
        if path:
            self._save_config_to_file(path)

    def _save_config_to_file(self, path):
        config = {
            'name': self.name_entry.get(),
            'version': self.version_entry.get(),
            'category': self.category_var.get(),
            'comment': self.comment_entry.get(),
            'executable_path': self.exe_entry.get(),
            'icon_path': self.icon_entry.get(),
        }
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            self._append_log(tr('cfg_saved', path))
        except (OSError, IOError) as e:
            messagebox.showerror(tr('err_title'), tr('err_save_cfg', e))

    def _load_config(self):
        path = filedialog.askopenfilename(
            title=tr('load_cfg_title'), filetypes=[(tr('json_files'), "*.json")],
        )
        if path:
            self._load_config_from_file(path)

    def _load_config_from_file(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                config = json.load(f)
        except (json.JSONDecodeError, ValueError) as e:
            messagebox.showerror(tr('err_title'), tr('err_load_json', e))
            return
        except (OSError, IOError) as e:
            messagebox.showerror(tr('err_title'), tr('err_read_file', e))
            return

        for entry, key in ((self.name_entry, 'name'), (self.version_entry, 'version'),
                           (self.comment_entry, 'comment'), (self.exe_entry, 'executable_path'),
                           (self.icon_entry, 'icon_path')):
            entry.delete(0, tk.END)
            entry.insert(0, str(config.get(key, '')))
        self.category_var.set(config.get('category', ''))
        self._append_log(tr('cfg_loaded', path))

    # --- Сборка ---
    def _set_build_state(self, building: bool):
        self.generate_button.config(state=tk.DISABLED if building else tk.NORMAL)
        self.cancel_button.config(state=tk.NORMAL if building else tk.DISABLED)

    def _cancel_build(self):
        if self._build_process and self._build_process.poll() is None:
            self._append_log(tr('cancelling'))
            self._build_process.terminate()
            try:
                self._build_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._build_process.kill()
        if self._builder:
            self._builder.cleanup()
            self._builder = None
        self._build_process = None
        self._set_build_state(False)
        self._append_log(tr('build_cancelled'))

    def _run_build(self):
        try:
            self._execute_build()
        except Exception as e:
            self._append_log(tr('unexpected_error', e))
            self.frame.after(0, lambda: messagebox.showerror(tr('err_title'), tr('err_build_failed', e)))
        finally:
            self._build_process = None
            self._build_thread = None
            self.frame.after(0, lambda: self._set_build_state(False))

    def build_appimage(self):
        if self._build_thread and self._build_thread.is_alive():
            return
        exe = self.exe_entry.get().strip()
        icon = self.icon_entry.get().strip()
        name = self.name_entry.get().strip()
        category = self.category_var.get().strip()

        if not all([exe, icon, name, category]):
            messagebox.showerror(tr('err_title'), tr('err_fill_fields'))
            return
        if not os.path.exists(exe):
            messagebox.showerror(tr('err_title'), tr('err_exe_not_found', exe))
            return
        if not os.path.exists(icon):
            messagebox.showerror(tr('err_title'), tr('err_icon_not_found', icon))
            return

        self._clear_log()
        self._set_build_state(True)
        self._build_thread = threading.Thread(target=self._run_build, daemon=True)
        self._build_thread.start()

    def _execute_build(self):
        exe = self.exe_entry.get().strip()
        icon = self.icon_entry.get().strip()
        name = self.name_entry.get().strip()
        version = self.version_entry.get().strip() or DEFAULT_APP_VERSION
        category = self.category_var.get().strip()
        comment = self.comment_entry.get().strip()

        config = BuildConfig(
            name=name, version=version, category=category, comment=comment,
            executable_path=Path(exe), icon_path=Path(icon),
        )

        desktop_content = self.desktop_handler.generate(config)
        self.frame.after(0, lambda: self.mediator.set_desktop_content(desktop_content))

        validation = self.desktop_handler.validate(desktop_content)
        if not validation.is_valid:
            self._append_log(validation.summary)
            return

        dependencies = self.mediator.get_dependencies()

        self._builder = AppDirBuilder(base_dir=Path.cwd())
        self._appdir_path = self._builder.create(config)
        self._append_log(tr('log_creating_appdir', self._appdir_path))

        self._builder.add_executable(config.executable_path)
        self._builder.add_icon(config.icon_path, name)
        desktop_path = self._builder.create_desktop_file(config, desktop_content)
        self._append_log(tr('log_desktop_created', desktop_path))

        apprun_path = self._builder.create_apprun_script(config.executable_path.name)
        self._append_log(tr('log_apprun_created', apprun_path))

        for dep in dependencies:
            dep_path = Path(dep)
            if dep_path.exists():
                dest = self._builder.appdir_path / "usr" / "lib" / dep_path.name
                shutil.copy2(dep_path, dest)
                self._append_log(tr('log_dep_added', dep_path.name))

        if not self.linuxdeploy.ensure_available(log_callback=self._append_log):
            self._append_log(tr('log_ld_missing'))
            self._builder.cleanup()
            self._builder = None
            return

        self._append_log(tr('log_running_ld'))
        cmd = [
            "linuxdeploy",
            "--appdir", str(self._appdir_path),
            "--output", "appimage",
            "--executable", str(self._appdir_path / "usr/bin" / config.executable_path.name),
            "--icon-file", str(self._appdir_path / "usr/share/icons/hicolor/256x256/apps" / f"{name}.png"),
        ]
        for dep in dependencies:
            dep_path = Path(dep)
            if dep_path.exists():
                cmd.extend(["--library", str(dep_path)])

        self._append_log(tr('log_executing', ' '.join(cmd)))
        self._build_process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        output = ""
        for line in iter(self._build_process.stdout.readline, ''):
            if line:
                output += line
                self._append_log(line.strip())
        self._build_process.stdout.close()
        self._build_process.wait()

        if self._build_process.returncode != 0:
            self._append_log(tr('log_build_error'))
            if "contains an unregistered value" in output:
                self._append_log(tr('log_categories_issue'))
                self._append_log(tr('log_check_validator'))
            self._builder.cleanup()
            self._builder = None
            return

        self._append_log(tr('log_build_ok'))
        self.frame.after(0, lambda: messagebox.showinfo(tr('success_title'), tr('success_build')))
        self._builder = None


# ============================================================================
# Вкладка валидатора
# ============================================================================

class ValidatorTab:
    def __init__(self, notebook, mediator):
        self.mediator = mediator
        self.handler = DesktopFileHandler()
        self.frame = ttk.Frame(notebook, padding=(16, 12))
        notebook.add(self.frame, text=tr('tab_validator'))

        self.header_label = ttk.Label(self.frame, text=tr('desktop_content'))
        self.header_label.pack(anchor=tk.W, pady=(0, 6))
        self.desktop_text = scrolledtext.ScrolledText(
            self.frame, height=14, bg=COLOR_CARD, fg=COLOR_TEXT,
            relief=tk.FLAT, font=('Consolas', 10),
        )
        self.desktop_text.pack(fill=tk.BOTH, expand=True)
        self.desktop_text.insert(tk.END, self.handler.get_sample())

        btn_frame = ttk.Frame(self.frame)
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        self.validate_button = ttk.Button(
            btn_frame, style='Accent.TButton', text=tr('validate_btn'), command=self._on_validate,
        )
        self.validate_button.pack(side=tk.LEFT)
        self.validation_result = ttk.Label(btn_frame, text="", foreground=COLOR_ERR)
        self.validation_result.pack(side=tk.LEFT, padx=(12, 0))

    def get_content(self) -> str:
        return self.desktop_text.get("1.0", tk.END)

    def set_content(self, content: str) -> None:
        self.desktop_text.delete("1.0", tk.END)
        self.desktop_text.insert(tk.END, content)

    def validate(self) -> ValidationResult:
        result = self.handler.validate(self.get_content())
        self.validation_result.config(text=result.summary, foreground=result.color)
        return result

    def _on_validate(self) -> None:
        self.validate()

    def apply_language(self):
        self.frame.master.tab(self.frame, text=tr('tab_validator'))
        self.header_label.config(text=tr('desktop_content'))
        self.validate_button.config(text=tr('validate_btn'))


# ============================================================================
# Вкладка зависимостей
# ============================================================================

class DependenciesTab:
    def __init__(self, notebook, mediator):
        self.mediator = mediator
        self.frame = ttk.Frame(notebook, padding=(16, 12))
        notebook.add(self.frame, text=tr('tab_deps'))

        entry_frame = ttk.Frame(self.frame)
        entry_frame.pack(fill=tk.X, pady=(0, 8))
        self.add_label = ttk.Label(entry_frame, text=tr('add_dependency'))
        self.add_label.pack(side=tk.LEFT, padx=(0, 8))
        self.deps_entry = ttk.Entry(entry_frame, width=36)
        self.deps_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6))
        self.add_button = ttk.Button(entry_frame, text=tr('add'), command=self.select_dependencies)
        self.add_button.pack(side=tk.LEFT, padx=(0, 6))
        self.sort_button = ttk.Button(entry_frame, text=tr('sort'), command=self.sort_dependencies)
        self.sort_button.pack(side=tk.LEFT)

        list_frame = ttk.Frame(self.frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        self.list_label = ttk.Label(list_frame, text=tr('dep_list'))
        self.list_label.pack(anchor=tk.W, pady=(0, 4))
        self.deps_listbox = tk.Listbox(
            list_frame, selectmode=tk.EXTENDED, relief=tk.FLAT,
            bg=COLOR_CARD, fg=COLOR_TEXT, highlightthickness=1,
            highlightbackground='#d1d5db', font=('Arial', 10),
        )
        self.deps_listbox.pack(fill=tk.BOTH, expand=True)

        btns = ttk.Frame(list_frame)
        btns.pack(fill=tk.X, pady=(8, 0))
        self.remove_button = ttk.Button(btns, text=tr('remove_selected'), command=self.remove_selected_dependency)
        self.remove_button.pack(side=tk.LEFT, padx=(0, 6))
        self.clear_button = ttk.Button(btns, text=tr('clear_all'), command=self.clear_dependencies)
        self.clear_button.pack(side=tk.LEFT)

    def select_dependencies(self):
        files = filedialog.askopenfilenames(title=tr('select_deps_title'))
        for f in files:
            fname = os.path.basename(f)
            if fname and fname not in self.get_dependencies():
                self.deps_listbox.insert(tk.END, fname)

    def remove_selected_dependency(self):
        for idx in reversed(self.deps_listbox.curselection()):
            self.deps_listbox.delete(idx)

    def clear_dependencies(self):
        self.deps_listbox.delete(0, tk.END)

    def sort_dependencies(self):
        deps = sorted(self.deps_listbox.get(0, tk.END))
        self.clear_dependencies()
        for dep in deps:
            self.deps_listbox.insert(tk.END, dep)

    def get_dependencies(self):
        return list(self.deps_listbox.get(0, tk.END))

    def set_dependencies(self, deps):
        self.clear_dependencies()
        for dep in deps:
            self.deps_listbox.insert(tk.END, dep)

    def apply_language(self):
        self.frame.master.tab(self.frame, text=tr('tab_deps'))
        self.add_label.config(text=tr('add_dependency'))
        self.list_label.config(text=tr('dep_list'))
        self.add_button.config(text=tr('add'))
        self.sort_button.config(text=tr('sort'))
        self.remove_button.config(text=tr('remove_selected'))
        self.clear_button.config(text=tr('clear_all'))


# ============================================================================
# Главное окно
# ============================================================================

class AppImageBuilderTk:
    def __init__(self, root):
        self.root = root
        self.root.title(tr('title'))
        self.root.geometry("880x640")
        self.root.minsize(760, 560)
        self.root.configure(bg=COLOR_BG)

        self._setup_style()

        main_frame = ttk.Frame(root, padding=(16, 10))
        main_frame.pack(fill=tk.BOTH, expand=True)

        # --- Шапка ---
        header = ttk.Frame(main_frame)
        header.pack(fill=tk.X, pady=(0, 10))

        title_block = ttk.Frame(header)
        title_block.pack(side=tk.LEFT)
        ttk.Label(
            title_block, text=tr('header'), style='Header.TLabel',
        ).pack(anchor=tk.W)
        self.subtitle_label = ttk.Label(
            title_block, text=tr('subtitle'), style='Sub.TLabel',
        )
        self.subtitle_label.pack(anchor=tk.W)

        lang_box = ttk.Combobox(
            header, width=4, state='readonly', values=['RU', 'EN'], takefocus=0,
        )
        lang_box.set(get_language().upper())
        lang_box.pack(side=tk.RIGHT)
        lang_box.bind('<<ComboboxSelected>>', lambda e: self._switch_language(lang_box))

        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        self.mediator = Mediator()

        self.build_tab = BuildTab(self.notebook, self.mediator)
        self.mediator.register_build_tab(self.build_tab)
        self.validator_tab = ValidatorTab(self.notebook, self.mediator)
        self.mediator.register_validator_tab(self.validator_tab)
        self.dependencies_tab = DependenciesTab(self.notebook, self.mediator)
        self.mediator.register_dependencies_tab(self.dependencies_tab)

        self.status_var = tk.StringVar(value=tr('status_ready'))
        self.mediator.set_status_callback(self.status_var.set)

        status_bar = ttk.Label(
            root, textvariable=self.status_var, style='Status.TLabel',
            anchor=tk.W, padding=(12, 4),
        )
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def _setup_style(self):
        style = ttk.Style()
        style.theme_use('clam')

        style.configure('.', background=COLOR_BG, foreground=COLOR_TEXT, font=('Segoe UI', 10))
        style.configure('TFrame', background=COLOR_BG)
        style.configure('TLabelframe', background=COLOR_BG, borderwidth=1, relief=tk.SOLID)
        style.configure('TLabelframe.Label', background=COLOR_BG, foreground=COLOR_MUTED)
        style.configure('TLabel', background=COLOR_BG, foreground=COLOR_TEXT)
        style.configure('Header.TLabel', font=('Segoe UI', 15, 'bold'), foreground=COLOR_TEXT)
        style.configure('Sub.TLabel', foreground=COLOR_MUTED)
        style.configure('Status.TLabel', background='#e5e7eb', foreground=COLOR_MUTED)

        style.configure('TButton', padding=(10, 5))
        style.map('TButton', background=[('active', '#dbeafe')])
        style.configure(
            'Accent.TButton', background=COLOR_ACCENT, foreground='#ffffff', padding=(14, 6),
        )
        style.map(
            'Accent.TButton',
            background=[('disabled', '#93c5fd'), ('pressed', COLOR_ACCENT_DARK), ('active', COLOR_ACCENT_DARK)],
            foreground=[('disabled', '#e5e7eb')],
        )

        style.configure('TNotebook', background=COLOR_BG, borderwidth=0)
        style.configure(
            'TNotebook.Tab', background='#e5e7eb', foreground=COLOR_MUTED,
            padding=(16, 7), font=('Segoe UI', 10, 'bold'),
        )
        style.map(
            'TNotebook.Tab',
            background=[('selected', COLOR_CARD)],
            foreground=[('selected', COLOR_ACCENT)],
        )

        style.configure('TEntry', padding=4)
        style.configure('TCombobox', padding=3)

    def _switch_language(self, lang_box):
        lang = lang_box.get().lower()
        set_language(lang)
        self.root.title(tr('title'))
        self.subtitle_label.config(text=tr('subtitle'))
        self.status_var.set(tr('status_ready'))
        self.mediator.rebuild_ui_texts()


def main():
    root = tk.Tk()
    AppImageBuilderTk(root)
    root.mainloop()


if __name__ == "__main__":
    main()
